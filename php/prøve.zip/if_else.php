<?php

$tall = rand(1,100);

if($tall < 50){
    echo"$tall er mindre en 50";

}else if($tall > 50 ){
    echo"$tall er større en 50";
}








?>