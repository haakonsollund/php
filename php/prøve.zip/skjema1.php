<form action="skjema2.php" method="GET">
    ditt navn
    <input type="text" name="ditnavn">

    hva er din favorittfilm?
    <input type="text" name="favorittfilm">

    <input type="submit" name="sendinn" value="send inn">
</form>